import asyncio
import time

import httpx
import pandas as pd


async def retrieve_documents(query: str) -> dict:
    url = "http://99.1.82.184:18080/api/v1/qdrant/retrieve"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    json = {
        "queries": [query],
        "reranking": {
            "is_active": True,
            "target": "text",
        },
        "filter": {
            "key": "group",
            "value": ["내부자료", "온나라"],
        },
    }
    async with httpx.AsyncClient() as client:
        response = await client.request(
            method="POST", url=url, headers=headers, json=json
        )
        return response.json()


async def get_data(row, response, df_dict, latency):
    for idx, doc in enumerate(response):
        # 가독성을 위해 검색결과 첫번째에만 저장
        if idx == 0:
            df_dict["파일명"].append(row["파일명"])
            df_dict["본문"].append(row["본문"])
            df_dict["질문"].append(row["질문"])
            df_dict["답변수정"].append(row["답변수정"])
            df_dict["참고 내용"].append(row["참고 내용"])
            df_dict["latency"].append(latency)
        else:
            df_dict["파일명"].append(None)
            df_dict["본문"].append(None)
            df_dict["질문"].append(None)
            df_dict["답변수정"].append(None)
            df_dict["참고 내용"].append(None)
            df_dict["latency"].append(None)
        # 항상 저장
        payload = doc.get("payload")
        df_dict["file"].append(payload.get("file"))
        df_dict["group"].append(payload.get("group"))
        df_dict["page_num"].append(payload.get("page_num"))
        df_dict["parent_text"].append(payload.get("parent_text"))
        df_dict["text"].append(payload.get("text"))
        df_dict["score"].append(doc.get("score"))


async def main(input_files: list[str]):
    for file in input_files:
        test_df = pd.read_excel(file)

        total_len = test_df["질문"].shape[0]
        print(total_len)

        df_dict = {
            "파일명": [],
            "본문": [],
            "질문": [],
            "답변수정": [],
            "참고 내용": [],
            "latency": [],
            "group": [],
            "file": [],
            "page_num": [],
            "parent_text": [],
            "text": [],
            "score": [],
        }

        for _, row in test_df.iterrows():
            start_time = time.perf_counter()
            response = await retrieve_documents(row["질문"])
            latency = f"{(time.perf_counter() - start_time):.4f}"
            response = response[0]

            await get_data(row, response, df_dict, latency)


if __name__ == "__main__":
    input_files = [
        "test_datas/251017_내부자료_테스트셋_질의응답.xlsx",
        "test_query/251017_온나라_테스트셋_질의응답.xlsx",
    ]
    output_files = [
        "outputs/2_4_inner_rerank01.xlsx",
        "outputs/2_4_onnar_rerank02.xlsx",
    ]
    asyncio.run(main(input_files))
