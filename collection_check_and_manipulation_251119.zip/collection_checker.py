from collections import Counter
from typing import Any

import pandas as pd
from qdrant_client import QdrantClient, models


class VectorDatabase:
    def __init__(self, host: str, port: int, collection_name: str | None = None):
        self.client = self.get_client(host, port)
        self.collection_name = self.set_collection_name(collection_name)

    def get_client(self, host: str, port: int) -> QdrantClient:
        """QdrantClient 반환"""
        return QdrantClient(host=host, port=port)

    def set_collection_name(self, collection_name: str) -> str:
        """collection 이름 지정"""
        return (
            collection_name if self.client.collection_exists(collection_name) else None
        )

    def _get_filters(
        self, filters: list[dict[str, list[Any]]] | None
    ) -> models.Filter | None:
        """Qdrant Filter 적용"""
        return (
            models.Filter(
                must=[
                    models.FieldCondition(
                        key=filter.get("key"),
                        match=models.MatchAny(any=filter.get("values")),
                    )
                    for filter in filters
                ]
            )
            if filters
            else None
        )

    def get_payload_keys(
        self,
        limit: int = 10_000,
        with_payload: bool = True,
        with_vectors: bool = False,
        filters: list[dict[str, list]] | None = None,
    ) -> dict[str, int | None]:
        """페이로드 종류 및 개수 반환"""
        key_counter = {}
        next_page_offset = None
        scroll_filter = self._get_filters(filters)

        while True:
            points, next_page_offset = self.client.scroll(
                collection_name=self.collection_name,
                scroll_filter=scroll_filter,
                offset=next_page_offset,
                limit=limit,
                with_payload=with_payload,
                with_vectors=with_vectors,
            )
            for p in points:
                for _key in p.payload.keys():
                    if key_counter.get(_key):
                        key_counter[_key] += 1
                    else:
                        key_counter[_key] = 1
            if next_page_offset is None:
                break
        return key_counter

    def get_payload_domains(
        self,
        target_key: str,
        limit: int = 10_000,
        with_payload: bool = True,
        with_vectors: bool = False,
        filters: list[dict[str, list]] | None = None,
    ) -> Counter:
        """특정 페이로드 키 값에 포함된 도메인 및 개수 반환"""
        domain_counter = Counter()
        next_offset = None
        scroll_filter = self._get_filters(filters)

        while True:
            points, next_offset = self.client.scroll(
                collection_name=self.collection_name,
                scroll_filter=scroll_filter,
                limit=limit,
                offset=next_offset,
                with_payload=with_payload,
                with_vectors=with_vectors,
            )
            for p in points:
                if target_key in p.payload:
                    val = p.payload[target_key]
                    # 리스트 형태 또는 단일값 모두 처리
                    if isinstance(val, list):
                        domain_counter.update(val)
                    else:
                        domain_counter[val] += 1

            if next_offset is None:
                break

        return domain_counter

    def get_file_list_by_group(self, group: str) -> list:
        """Group 별 임베딩된 문서목록(리스트) 반환"""
        filters = [{"key": "group", "values": [group]}]
        domains: Counter = self.get_payload_domains(target_key="file", filters=filters)

        files = list(domains.keys())
        # 파일번호 기준 오름차순 정렬
        sorted_files = sorted(files, key=lambda x: int(x.split("_")[0]))
        return sorted_files


def main(output_file: str, host: str, port: int, collection_name: str | None = None):
    vector_db = VectorDatabase(host, port, collection_name)
    files_df_list = []
    columns = ["total"]  # sheet 1번 결과값의 컬럼 및 파일목록 시트 순서를 위한 list
    sheet1_dict = {"total": vector_db.get_payload_keys()}
    print("✅ 모든 points의 payload 종류 및 개수 확인")

    # 전체 group 도메인 목록 확인
    group_domains: dict = vector_db.get_payload_domains("group")
    groups = list(group_domains.keys())
    print("✅ collection 내 전체 group 목록 확인")

    for group in groups:
        filters = [{"key": "group", "values": [group]}]

        # group 별 페이로드 종류 및 개수 확인
        try:
            sheet1_dict[group] = vector_db.get_payload_keys(filters=filters)
            columns.append(group)
            print(f"✅ group-{group} payload 종류 및 개수 확인")
        except Exception as e:
            print(f"🚨 group-{group} payload 종류 및 개수 확인 중 에러 발생")
            print(e)

        # group 별 문서 목록 저장
        _df = pd.DataFrame(
            {"file": vector_db.get_file_list_by_group(group)}, index=None
        )
        files_df_list.append(_df)
        print(f"✅ group-{group} 파일 목록 확인")

    # 결과값 excel로 저장
    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        # sheet1 >> group 별 payload 종류 및 개수
        pd.DataFrame(sheet1_dict, columns=columns).fillna(0).to_excel(
            writer, sheet_name="payload_counts"
        )
        # sheet2 ~ >> group 별 파일 목록
        for idx, _df in enumerate(files_df_list):
            _df.to_excel(writer, sheet_name=f"{columns[idx + 1]} 파일목록", index=False)
    print(f"✅ 전체 작업 완료 / '{output_file}' 저장")


if __name__ == "__main__":
    # host = "localhost"
    # port = 6333
    # collection_name = "late_512_251104"
    # vector_db = VectorDatabase(host, port, collection_name)
    # file_list = vector_db.get_file_list_by_group("부산연구원")
    # print(file_list)
    # print(len(file_list))

    host = "localhost"
    port = 6333
    collection_name = "late_512_in_on_home_law_bdi_data"
    output_file = f"{collection_name}_analysis_results.xlsx"

    main(
        host=host,
        port=port,
        collection_name=collection_name,
        output_file=output_file,
    )
