# jsonl to excel


```sh
# 실행명령어 및 인자
  python jsonl_to_excel.py \
    --input outputs/251104_results.jsonl \
    --output outputs/251104_results.xlsx \
    --topk 0 \
    --truncate-text 0
```


