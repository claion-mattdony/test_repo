# jsonl to excel


```sh
# 실행명령어 및 인자
  uv run python jsonl_to_excel_v2.py \
    --input outputs/251030_onnara_results.jsonl \
    --output outputs/251030_onnara_results.xlsx \
    --topk 0 \
    --truncate-text 0
```